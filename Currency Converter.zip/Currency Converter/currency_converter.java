import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class currency_converter extends Frame implements ActionListener,ItemListener{

	JLabel l1,l2,l3,l4,l5;
	JComboBox cb1,cb2;
	JTextField t1;
	ImageIcon i1,i2,i3,i4,i5,i6,i7,i8;
	ImageIcon ii1,ii2,ii3,ii4,ii5,ii6,ii7,ii8;
	JButton b1;
	String from[]={"Dollar","Euro","Pound","Rupee","Yen","Dinar","Peso","Ruble"};
	String to[]={"Dollar","Euro","Pound","Rupee","Yen","Dinar","Peso","Ruble"};

	public currency_converter(){
		setVisible(true);
		setSize(700,700);
		setLayout(null);
		setBackground( Color.decode("#88E0EF") );

		l1=new JLabel("Currency Converter");
		l1.setBounds(100,65,500,70);
		l1.setFont(new Font("Times New Roman", Font.BOLD, 55));
		// l1.setOpaque(true);
		l1.setForeground(Color.decode("#FEFBF6"));
		add(l1);

		l2=new JLabel("Amount");
		l2.setBounds(115,180,200,50);
		l2.setFont(new Font("Times New Roman", Font.BOLD, 35));
		// l1.setOpaque(true);
		// l1.setBackground(Color.BLUE);
		add(l2);

		t1=new JTextField();
		t1.setBounds(300,185,240,50);
		t1.setFont(new Font("TImes New Roman",Font.ITALIC,35));
		add(t1);

		l3=new JLabel("From");
		l3.setBounds(115,295,200,50);
		l3.setFont(new Font("Times New Roman", Font.BOLD, 35));
		// l1.setOpaque(true);
		// l1.setBackground(Color.BLUE);
		add(l3);

		cb1=new JComboBox(from);
		cb1.setFont(new Font("Times New Roman", Font.BOLD, 23));
		cb1.setBounds(300,295,200,50);
		add(cb1);
		cb1	.addItemListener(this);    

		l4=new JLabel("To");
		l4.setBounds(115,410,200,50);
		l4.setFont(new Font("Times New Roman", Font.BOLD, 35));
		// l1.setOpaque(true);
		// l1.setBackground(Color.BLUE);
		add(l4);

		cb2=new JComboBox(to);
		cb2.setFont(new Font("Times New Roman", Font.BOLD, 23));
		cb2.setBounds(300,410,200,50);
		add(cb2);
		cb2.addItemListener(this);

		b1=new JButton("Convert");
		b1.setBounds(200,530,200,70);
		b1.setFont(new Font("Times New Roman", Font.BOLD, 28));
		add(b1);
		b1.addActionListener(this);

		l4=new JLabel();
		l4.setBounds(550,295,50,50);
		add(l4);

		l5=new JLabel();
		l5.setBounds(550,410,50,50);
		add(l5);

		i1=new ImageIcon(new ImageIcon("dollar.jpg").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		i2=new ImageIcon(new ImageIcon("euro.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		i3=new ImageIcon(new ImageIcon("pound.jpg").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		i4=new ImageIcon(new ImageIcon("rupee.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		i5=new ImageIcon(new ImageIcon("yen.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		i6=new ImageIcon(new ImageIcon("dinar.jpg").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		i7=new ImageIcon(new ImageIcon("peso.jpg").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		i8=new ImageIcon(new ImageIcon("ruble.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));

		ii1=new ImageIcon(new ImageIcon("dollar.jpg").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		ii2=new ImageIcon(new ImageIcon("euro.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		ii3=new ImageIcon(new ImageIcon("pound.jpg").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		ii4=new ImageIcon(new ImageIcon("rupee.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		ii5=new ImageIcon(new ImageIcon("yen.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		ii6=new ImageIcon(new ImageIcon("dinar.jpg").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		ii7=new ImageIcon(new ImageIcon("peso.jpg").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));
		ii8=new ImageIcon(new ImageIcon("ruble.png").getImage().getScaledInstance(50, 50, Image.SCALE_DEFAULT));


		//{"Dollar","Euro","Pound","Rupee","Yen","Dinar","Peso","Ruble"};

	}
	public void actionPerformed(ActionEvent ae){
		String s=ae.getActionCommand();
		if (s.equals("Convert")) {
			Double amt;
        	Double amount = Double.parseDouble(t1.getText());

        	//*******************************Dollar******************************************

			if (cb1.getSelectedItem().toString()=="Euro" && cb2.getSelectedItem().toString()=="Dollar") {
						amt=amount*0.97;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	

			if (cb1.getSelectedItem().toString()=="Pound" && cb2.getSelectedItem().toString()=="Dollar") {
						amt=amount*1.11;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}		
			if (cb1.getSelectedItem().toString()=="Rupee" && cb2.getSelectedItem().toString()=="Dollar") {
						amt=amount*0.012;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Yen" && cb2.getSelectedItem().toString()=="Dollar") {
						amt=amount*0.0069;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Dinar" && cb2.getSelectedItem().toString()=="Dollar") {
						amt=amount*0.017;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Ruble" && cb2.getSelectedItem().toString()=="Dollar") {
						amt=amount*0.016;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Dollar" && cb2.getSelectedItem().toString()=="Dollar") {
						amt=amount*1;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}

			//*******************************Euro******************************************

			if (cb1.getSelectedItem().toString()=="Euro" && cb2.getSelectedItem().toString()=="Euro") {
						amt=amount*1;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}

			if (cb1.getSelectedItem().toString()=="Pound" && cb2.getSelectedItem().toString()=="Euro") {
						amt=amount*1.14;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	

			if (cb1.getSelectedItem().toString()=="Rupee" && cb2.getSelectedItem().toString()=="Euro") {
						amt=amount*0.12;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Yen" && cb2.getSelectedItem().toString()=="Euro") {
						amt=amount*0.0071;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Dinar" && cb2.getSelectedItem().toString()=="Euro") {
						amt=amount*3.30;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Peso" && cb2.getSelectedItem().toString()=="Euro") {
						amt=amount*0.017;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Ruble" && cb2.getSelectedItem().toString()=="Euro") {
						amt=amount*0.016;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			
			//*******************************Pound******************************************

			if (cb1.getSelectedItem().toString()=="Dollar" && cb2.getSelectedItem().toString()=="Pound") {
						amt=amount*0.90;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}

			if (cb1.getSelectedItem().toString()=="Euro" && cb2.getSelectedItem().toString()=="Pound") {
						amt=amount*0.88;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	

			if (cb1.getSelectedItem().toString()=="Pound" && cb2.getSelectedItem().toString()=="Pound") {
						amt=amount*1;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Rupee" && cb2.getSelectedItem().toString()=="Pound") {
						amt=amount*0.011;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Yen" && cb2.getSelectedItem().toString()=="Pound") {
						amt=amount*0.0062;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Dinar" && cb2.getSelectedItem().toString()=="Pound") {
						amt=amount*2.90;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Peso" && cb2.getSelectedItem().toString()=="Pound") {
						amt=amount*0.015;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Ruble" && cb2.getSelectedItem().toString()=="Pound") {
						amt=amount*0.014;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	

			//*******************************Rupee******************************************

			if (cb1.getSelectedItem().toString()=="Dollar" && cb2.getSelectedItem().toString()=="Rupee") {
						amt=amount*82.883;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}

			if (cb1.getSelectedItem().toString()=="Euro" && cb2.getSelectedItem().toString()=="Rupee") {
						amt=amount*80.72;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	

			if (cb1.getSelectedItem().toString()=="Pound" && cb2.getSelectedItem().toString()=="Rupee") {
						amt=amount*91.83;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Rupee" && cb2.getSelectedItem().toString()=="Rupee") {
						amt=amount*1;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Yen" && cb2.getSelectedItem().toString()=="Rupee") {
						amt=amount*0.57;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Dinar" && cb2.getSelectedItem().toString()=="Rupee") {
						amt=amount*266.03;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Peso" && cb2.getSelectedItem().toString()=="Rupee") {
						amt=amount*1.40;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Ruble" && cb2.getSelectedItem().toString()=="Rupee") {
						amt=amount*1.33;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}

			//*******************************Yen******************************************

			if (cb1.getSelectedItem().toString()=="Dollar" && cb2.getSelectedItem().toString()=="Yen") {
						amt=amount*145.36;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}

			if (cb1.getSelectedItem().toString()=="Euro" && cb2.getSelectedItem().toString()=="Yen") {
						amt=amount*141.59;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	

			if (cb1.getSelectedItem().toString()=="Pound" && cb2.getSelectedItem().toString()=="Yen") {
						amt=amount*161.80;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Rupee" && cb2.getSelectedItem().toString()=="Yen") {
						amt=amount*1.75;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Yen" && cb2.getSelectedItem().toString()=="Yen") {
						amt=amount*1;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Dinar" && cb2.getSelectedItem().toString()=="Yen") {
						amt=amount*466.86;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Peso" && cb2.getSelectedItem().toString()=="Yen") {
						amt=amount*2.46;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Ruble" && cb2.getSelectedItem().toString()=="Yen") {
						amt=amount*2.33;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}

			//*******************************Dinar******************************************

			if (cb1.getSelectedItem().toString()=="Dollar" && cb2.getSelectedItem().toString()=="Dinar") {
						amt=amount*0.31;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Euro" && cb2.getSelectedItem().toString()=="Dinar") {
						amt=amount*0.30;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Pound" && cb2.getSelectedItem().toString()=="Dinar") {
						amt=amount*0.34;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Rupee" && cb2.getSelectedItem().toString()=="Dinar") {
						amt=amount*0.0037;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Yen" && cb2.getSelectedItem().toString()=="Dinar") {
						amt=amount*0.0021;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Dinar" && cb2.getSelectedItem().toString()=="Dinar") {
						amt=amount*1;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Peso" && cb2.getSelectedItem().toString()=="Dinar") {
						amt=amount*0.0052;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Ruble" && cb2.getSelectedItem().toString()=="Dinar") {
						amt=amount*0.0050;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}

			//*******************************Peso******************************************

			if (cb1.getSelectedItem().toString()=="Dollar" && cb2.getSelectedItem().toString()=="Peso") {
						amt=amount*59.05;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Euro" && cb2.getSelectedItem().toString()=="Peso") {
						amt=amount*57.54;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Pound" && cb2.getSelectedItem().toString()=="Peso") {
						amt=amount*65.49;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Rupee" && cb2.getSelectedItem().toString()=="Peso") {
						amt=amount*0.71;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Yen" && cb2.getSelectedItem().toString()=="Peso") {
						amt=amount*0.41;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Dinar" && cb2.getSelectedItem().toString()=="Peso") {
						amt=amount*189.65;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Peso" && cb2.getSelectedItem().toString()=="Peso") {
						amt=amount*1;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Ruble" && cb2.getSelectedItem().toString()=="Peso") {
						amt=amount*0.95;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}


			//*******************************Ruble******************************************

			if (cb1.getSelectedItem().toString()=="Dollar" && cb2.getSelectedItem().toString()=="Ruble") {
						amt=amount*62.35;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Euro" && cb2.getSelectedItem().toString()=="Ruble") {
						amt=amount*60.76;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Pound" && cb2.getSelectedItem().toString()=="Ruble") {
						amt=amount*69.12;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Rupee" && cb2.getSelectedItem().toString()=="Ruble") {
						amt=amount*0.75;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}	
			if (cb1.getSelectedItem().toString()=="Yen" && cb2.getSelectedItem().toString()=="Ruble") {
						amt=amount*0.43;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Dinar" && cb2.getSelectedItem().toString()=="Ruble") {
						amt=amount*200.25;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Peso" && cb2.getSelectedItem().toString()=="Ruble") {
						amt=amount*1.06;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}
			if (cb1.getSelectedItem().toString()=="Ruble" && cb2.getSelectedItem().toString()=="Ruble") {
						amt=amount*1;
						JOptionPane.showMessageDialog(this,""+amt);  						
			}

		}
	}

	public void itemStateChanged(ItemEvent ie){
		int i=cb1.getSelectedIndex(); 
		int j=cb2.getSelectedIndex(); 

		if (i==0) {
			l4.setIcon(i1);				//dollar
		}
		if (i==1) {
			l4.setIcon(i2);				//Euro
		}
		if (i==2) {
			l4.setIcon(i3);				//pound
		}
		if (i==3) {
			l4.setIcon(i4);				//rupee
		}
		if (i==4) {
			l4.setIcon(i5);				//yen
		}
		if (i==5) {
			l4.setIcon(i6);				//dinar
		}
		if (i==6) {
			l4.setIcon(i7);				//peso
		}
		if (i==7) {
			l4.setIcon(i8);				//ruble
		}

		if (j==0) {
			l5.setIcon(ii1);				//dollar
		}
		if (j==1) {
			l5.setIcon(ii2);				//Euro
		}
		if (j==2) {
			l5.setIcon(ii3);				//pound
		}
		if (j==3) {
			l5.setIcon(ii4);				//rupee
		}
		if (j==4) {
			l5.setIcon(ii5);				//yen
		}
		if (j==5) {
			l5.setIcon(ii6);				//dinar
		}
		if (j==6) {
			l5.setIcon(ii7);				//peso
		}
		if (j==7) {
			l5.setIcon(ii8);				//ruble
		}
	}
	
	public static void main(String[] args) {
		currency_converter cc= new currency_converter();
	}
}